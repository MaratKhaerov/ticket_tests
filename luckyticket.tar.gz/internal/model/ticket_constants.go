package model

const (
	TICKET_COST          = uint(10)
	LUCKY_TICKET_VALUE   = 1
	UNLUCKY_TICKET_VALUE = -10
)
